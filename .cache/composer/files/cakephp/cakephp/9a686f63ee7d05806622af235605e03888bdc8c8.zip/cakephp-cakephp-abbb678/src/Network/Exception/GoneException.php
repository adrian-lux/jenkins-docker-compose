<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\GoneException', 'Cake\Network\Exception\GoneException');
deprecationWarning('Use Cake\Http\Exception\GoneException instead of Cake\Network\Exception\GoneException.');
