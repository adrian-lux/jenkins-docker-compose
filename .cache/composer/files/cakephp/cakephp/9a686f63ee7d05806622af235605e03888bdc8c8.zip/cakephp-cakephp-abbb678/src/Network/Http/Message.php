<?php
// @deprecated 3.4.0 Load new class and alias.
class_exists('Cake\Http\Client\Message');
deprecationWarning('Use Cake\Http\Client\Message instead of Cake\Network\Http\Message.');
