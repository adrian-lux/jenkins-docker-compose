<?php
// @deprecated 3.5.0 Backward compatibility with 2.x, 3.0.x
class_alias('Cake\Mailer\Email', 'Cake\Network\Email\Email');
deprecationWarning('Use Cake\Mailer\Email instead of Cake\Network\Email\Email.');
