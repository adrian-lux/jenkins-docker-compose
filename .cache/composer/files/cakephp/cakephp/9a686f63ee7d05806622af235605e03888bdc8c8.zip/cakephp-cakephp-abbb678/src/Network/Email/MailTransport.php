<?php
// @deprecated 3.5.0 Backward compatibility with 2.x, 3.0.x
class_alias('Cake\Mailer\Transport\MailTransport', 'Cake\Network\Email\MailTransport');
deprecationWarning('Use Cake\Mailer\Transport\MailTransport instead of Cake\Network\Email\MailTransport.');
